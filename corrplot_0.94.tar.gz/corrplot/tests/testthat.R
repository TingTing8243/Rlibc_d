library(testthat)
library(corrplot)

test_check('corrplot')
